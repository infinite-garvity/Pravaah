/* ==========================================================================
   PRAVAAH STUDIO — shared behaviour for every page (index.html, team.html)
   Needs: GSAP 3.12.5 + ScrollTrigger, Lenis 1.3.26 (loaded before this file).
   Every part checks for its own elements, so one file serves both pages.
   ========================================================================== */
(() => {
  'use strict';
  /* ---------- helpers ---------- */
  const root = document.documentElement;
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const cssVar = n => getComputedStyle(root).getPropertyValue(n).trim();
  const num = (n, f) => { const v = parseFloat(cssVar(n)); return Number.isFinite(v) ? v : f; };
  const lerp = (a, b, t) => a + (b - a) * t;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const DPR = () => Math.min(window.devicePixelRatio || 1, 2);
  const hex2rgb = h => { h = h.replace('#', ''); if (h.length === 3) h = h.split('').map(c => c + c).join(''); const n = parseInt(h, 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  const RM = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const FINE = matchMedia('(hover: hover) and (pointer: fine)').matches;
  const HAS_GSAP = !!(window.gsap && window.ScrollTrigger);
  const COL = {
    magenta: cssVar('--magenta'), gold: cssVar('--gold'), violet: cssVar('--violet'), violetText: cssVar('--violet-text'), ink: cssVar('--ink'),
    l1: cssVar('--logo-1'), l2: cssVar('--logo-2'), l3: cssVar('--logo-3'), l4: cssVar('--logo-4'), l5: cssVar('--logo-5')
  };
  const EASE = cssVar('--gsap-ease').replace(/["']/g, '') || 'expo.out';
  if (HAS_GSAP) { gsap.registerPlugin(ScrollTrigger); ScrollTrigger.config({ ignoreMobileResize: true }); }
  $$('[data-year]').forEach(el => { el.textContent = new Date().getFullYear(); });

  let refreshTimer = 0;
  const scheduleRefresh = () => { clearTimeout(refreshTimer); refreshTimer = setTimeout(() => { if (HAS_GSAP) ScrollTrigger.refresh(); else Current.rebuild(); }, 120); };

  /* ---------- smooth scroll (Lenis + ScrollTrigger) ---------- */
  let lenis = null;
  if (!RM && window.Lenis) {
    lenis = new Lenis({ lerp: 0.085, smoothWheel: true, wheelMultiplier: 1, touchMultiplier: 1.2 });
    if (HAS_GSAP) {
      lenis.on('scroll', ScrollTrigger.update);
      gsap.ticker.add(t => lenis.raf(t * 1000));
      gsap.ticker.lagSmoothing(0);
    } else {
      const loop = t => { lenis.raf(t); requestAnimationFrame(loop); };
      requestAnimationFrame(loop);
    }
  }
  $$('a[href^="#"]').forEach(a => a.addEventListener('click', e => {
    const id = a.getAttribute('href');
    if (id.length < 2) { e.preventDefault(); return; }
    const t = $(id); if (!t) return;
    e.preventDefault();
    if (lenis) lenis.scrollTo(t, { duration: 1.6 }); else t.scrollIntoView({ behavior: RM ? 'auto' : 'smooth' });
    if (!t.hasAttribute('tabindex')) t.setAttribute('tabindex', '-1');
    t.focus({ preventScroll: true });
  }));

  /* ---------- header: hide on scroll down, show on scroll up ---------- */
  const header = $('.site-header');
  if (header) {
    let lastY = scrollY;
    addEventListener('scroll', () => {
      const y = scrollY, d = y - lastY;
      if (Math.abs(d) > 4) {
        header.classList.toggle('is-hidden', d > 0 && y > 140 && !header.contains(document.activeElement));
        lastY = y;
      }
      header.classList.toggle('is-scrolled', y > 40);
    }, { passive: true });
    header.addEventListener('focusin', () => header.classList.remove('is-hidden'));
  }

  /* ---------- film grain (one generated tile, moved on the compositor) ---------- */
  (() => {
    const g = $('.grain'); if (!g) return;
    const c = document.createElement('canvas'); c.width = c.height = 180;
    const x = c.getContext('2d'); const d = x.createImageData(180, 180);
    for (let i = 0; i < d.data.length; i += 4) { const v = Math.random() * 255 | 0; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 40 + Math.random() * 120 | 0; }
    x.putImageData(d, 0, 0); g.style.backgroundImage = `url(${c.toDataURL('image/png')})`;
  })();

  /* ---------- TEAM PAGE: render members from window.TEAM ---------- */
  const silhouette = '<svg viewBox="0 0 60 60" aria-hidden="true"><circle cx="30" cy="22" r="11" fill="currentColor"/><path d="M8 56c2-13 11-20 22-20s20 7 22 20" fill="currentColor"/></svg>';
  function renderTeam() {
    const list = $('#members'); if (!list || !Array.isArray(window.TEAM)) return;
    const joinCard = $('.member-join', list);
    const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
    window.TEAM.forEach((m, i) => {
      const name = m.name || 'Name', role = m.role || 'Role', id = `member-${i + 1}`;
      const li = el('li', 'member'); li.dataset.cursor = 'team'; li.dataset.reveal = '';
      const mag = el('div', 'mag'), card = el('div', 'card3d');
      // front
      const front = el('div', 'face front');
      const photo = el('div', 'm-photo');
      if (m.photo) { const img = el('img'); img.src = m.photo; img.alt = `${name}, ${role}`; img.loading = 'lazy'; img.decoding = 'async'; photo.appendChild(img); }
      else { photo.innerHTML = silhouette; photo.setAttribute('role', 'img'); photo.setAttribute('aria-label', `Photo placeholder for ${name}`); }
      const trig = el('button', 'flip-trigger'); trig.type = 'button'; trig.dataset.cursor = 'team';
      trig.setAttribute('aria-expanded', 'false'); trig.setAttribute('aria-controls', id);
      trig.appendChild(el('span', 'sr-only', `Read about ${name}`));
      front.append(photo, el('h3', 'm-name', name), el('p', 'm-role', role), trig);
      // back
      const back = el('div', 'face back'); back.id = id; back.inert = true;
      back.setAttribute('role', 'group'); back.setAttribute('aria-label', `About ${name}`);
      const actions = el('div', 'm-actions');
      if (m.linkedin) { const a = el('a', 'm-link'); a.href = m.linkedin; a.target = '_blank'; a.rel = 'noopener'; a.innerHTML = 'LinkedIn <span aria-hidden="true">↗</span>'; a.setAttribute('aria-label', `${name} on LinkedIn (opens in a new tab)`); actions.appendChild(a); }
      const close = el('button', 'm-close', 'Flip back'); close.type = 'button'; actions.appendChild(close);
      back.append(el('p', 'm-back-name', name), el('p', 'm-intro', m.intro || ''), actions);
      card.append(front, back); mag.appendChild(card); li.appendChild(mag); list.insertBefore(li, joinCard);
    });
    const count = $('[data-team-count]'); if (count) count.textContent = window.TEAM.length;
  }

  function initFlip() {
    const cards = $$('.member:not(.member-join)'); if (!cards.length) return;
    let open = null;
    const setOpen = (card, on, focus) => {
      const trig = $('.flip-trigger', card), front = $('.front', card), back = $('.back', card);
      card.classList.toggle('is-flipped', on);
      trig.setAttribute('aria-expanded', String(on));
      back.inert = !on; front.inert = on;
      if (on) { open = card; if (focus) setTimeout(() => $('.m-close', back).focus({ preventScroll: true }), RM ? 0 : 320); }
      else { if (open === card) open = null; if (focus) trig.focus({ preventScroll: true }); }
    };
    cards.forEach(card => {
      $('.flip-trigger', card).addEventListener('click', e => {
        if (open && open !== card) setOpen(open, false);
        setOpen(card, true, e.detail === 0);   // keyboard activation moves focus to the back
      });
      $('.m-close', card).addEventListener('click', () => setOpen(card, false, true));
    });
    // a click or tap anywhere outside the open card flips it back
    document.addEventListener('click', e => { if (open && !open.contains(e.target)) setOpen(open, false); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && open) setOpen(open, false, true); });
  }

  /* ---------- THE CURRENT: one SVG river through the page ---------- */
  const Current = (() => {
    const svg = $('#currentSvg');
    if (!svg) return { init() {}, rebuild() {} };
    let routes = [], H = 0, head = null, headGlow = null;
    const proxy = { p: 0 };

    // layout box relative to <body>, ignoring transforms (parallax/reveals don't skew it)
    const box = el => {
      let x = 0, y = 0, e = el;
      while (e && e !== document.body) { x += e.offsetLeft; y += e.offsetTop; e = e.offsetParent; }
      const w = el.offsetWidth, h = el.offsetHeight;
      return { l: x, t: y, w, h, r: x + w, b: y + h, cx: x + w / 2, cy: y + h / 2 };
    };
    const smooth = (pts, lead, tail) => {
      const P = [lead || pts[0], ...pts, tail || pts[pts.length - 1]];
      let d = `M${pts[0][0].toFixed(1)},${pts[0][1].toFixed(1)}`;
      for (let i = 1; i < P.length - 2; i++) {
        const p0 = P[i - 1], p1 = P[i], p2 = P[i + 1], p3 = P[i + 2];
        const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
        const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
        d += ` C${c1[0].toFixed(1)},${c1[1].toFixed(1)} ${c2[0].toFixed(1)},${c2[1].toFixed(1)} ${p2[0].toFixed(1)},${p2[1].toFixed(1)}`;
      }
      return d;
    };
    const ending = (W, R, main) => {
      const foot = box($('#contact')), close = box($('.closing'));
      main.push([W * .7, foot.t + (close.t - foot.t) * .45], [close.l + 6, close.t - 24]);
      return R;
    };

    function layoutHome(W, mob) {
      const hero = box($('#hero')), about = box($('#about')), grid = box($('.principles'));
      const cards = $$('.principle').map(box);
      const jHead = box($('.journey-head')), nodes = $$('.node').map(box);
      const tenets = box($('.tenets')), flowBy = box($('#flow-by'));
      const peb = $$('.cluster .pebble').map(box);
      const cl = { l: Math.min(...peb.map(p => p.l)), r: Math.max(...peb.map(p => p.r)), t: Math.min(...peb.map(p => p.t)), b: Math.max(...peb.map(p => p.b)) };
      cl.cy = (cl.t + cl.b) / 2;
      const R = [];
      let main;
      if (!mob) {
        const Sp = [W * .5, grid.t - 70], Mp = [W * .5, grid.b + 130];
        const preSp = [W * .3, grid.t - 190], postMp = [W * .86, jHead.cy];
        const lcx = cards[0].cx, rcx = cards[1].cx;
        main = [
          [W * .9, 0], [W * .86, hero.t + hero.h * .36], [W * .6, hero.t + hero.h * .78], [W * .16, hero.b + 40],
          [W * .07, about.t + about.h * .14], [W * .045, about.t + about.h * .5], [W * .08, about.b - about.h * .08],
          preSp, Sp, [W * .5, grid.t + grid.h * .3], [W * .5, grid.t + grid.h * .72], Mp, postMp,
          [W * .62, nodes[0].cy - 170]
        ];
        nodes.forEach((n, i) => {
          main.push([n.cx, n.cy]);
          if (nodes[i + 1]) main.push([W * .5 + (i % 2 ? -1 : 1) * W * .06, (n.cy + nodes[i + 1].cy) / 2]);
        });
        const lastN = nodes[nodes.length - 1];
        const gl = Math.max(20, cl.l - 56), gr = Math.min(W - 20, cl.r + 56);
        const preTs = [W * .1, cl.t - 60], postTs = [W * .72, cl.b + 160];
        main.push([W * .3, lastN.cy + 150], [tenets.l + 8, flowBy.t + 40], [tenets.l + 8, flowBy.t + flowBy.h * .4], [tenets.l + 8, flowBy.b - flowBy.h * .18],
          preTs, [gl, cl.cy], [W * .5, cl.b + 26], [gr, cl.cy]);
        R.push({ pts: [Sp, [lcx, grid.t + grid.h * .25], [lcx, grid.t + grid.h * .75], Mp], lead: preSp, tail: postMp, color: COL.magenta });
        R.push({ pts: [Sp, [rcx, grid.t + grid.h * .25], [rcx, grid.t + grid.h * .75], Mp], lead: preSp, tail: postMp, color: COL.violet });
        R.push({ pts: [[gl, cl.cy], [W * .5, cl.t - 18], [gr, cl.cy]], lead: preTs, tail: postTs, color: COL.l1 });
      } else {
        main = [
          [W * .86, 0], [W * .92, hero.t + hero.h * .5], [W * .12, hero.b + 20],
          [W * .04, about.t + about.h * .2], [W * .05, about.b - about.h * .2],
          [W * .03, grid.t + grid.h * .1], [W * .97, grid.t + grid.h * .45], [W * .03, grid.t + grid.h * .85], [W * .5, grid.b + 40],
          [W * .97, jHead.cy]
        ];
        nodes.forEach((n, i) => {
          main.push([n.cx, n.cy]);
          if (nodes[i + 1]) main.push([n.cx + W * .035, (n.cy + nodes[i + 1].cy) / 2]);
        });
        const lastN = nodes[nodes.length - 1];
        main.push([lastN.cx, lastN.cy + 140], [W * .03, flowBy.t + 40], [W * .03, flowBy.b - 60], [W * .04, cl.cy], [W * .5, cl.b + 30], [W * .95, cl.cy]);
      }
      R.unshift({ pts: main, lead: [W * .9, -200], main: true });
      return ending(W, R, main);
    }

    function layoutTeam(W, mob) {
      const hero = box($('.team-hero')), grid = box($('#members'));
      const mem = $$('.member').map(box);
      const main = [[W * .9, 0], [W * .84, hero.t + hero.h * .45], [W * .3, hero.b - 20]];
      if (!mob && mem.length) {
        const cols = Math.max(1, getComputedStyle($('#members')).gridTemplateColumns.split(' ').length);
        const rows = Math.ceil(mem.length / cols);
        const gl = Math.max(20, grid.l - 46), gr = Math.min(W - 20, grid.r + 46);
        const cys = [];
        for (let r = 0; r < rows; r++) { const row = mem.slice(r * cols, r * cols + cols); cys.push(row.reduce((s, m) => s + m.cy, 0) / row.length); }
        cys.forEach((cy, r) => { main.push([r % 2 ? gr : gl, cy]); if (cys[r + 1] != null) main.push([W * .5, (cy + cys[r + 1]) / 2]); });
        main.push([W * .5, grid.b + 90]);
      } else {
        mem.forEach(m => main.push([m.l > W * .25 ? W * .06 : W * .94, m.cy]));
      }
      return ending(W, [{ pts: main, lead: [W * .9, -200], main: true }], main);
    }

    function rebuild() {
      const W = document.body.clientWidth; H = document.body.offsetHeight;
      const mob = W < 760;
      const R = $('#journey') ? layoutHome(W, mob) : $('#members') ? layoutTeam(W, mob) : null;
      if (!R) return;
      svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
      const cyc = [COL.l1, COL.l3, COL.l5, COL.l3];
      const bands = Math.max(3, Math.round(H / 1100));
      let stops = '';
      for (let i = 0; i <= bands; i++) stops += `<stop offset="${(i / bands).toFixed(3)}" stop-color="${cyc[i % cyc.length]}"/>`;
      let html = `<defs><linearGradient id="curGrad" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="${H}">${stops}</linearGradient></defs>`;
      R.forEach(r => {
        const d = smooth(r.pts, r.lead, r.tail), s = r.color || 'url(#curGrad)';
        html += `<g><path class="l-glow" d="${d}" stroke="${s}"/><path class="l-mid" d="${d}" stroke="${s}"/><path class="l-core" d="${d}" stroke="${s}"/></g>`;
      });
      html += `<circle class="head-glow" r="15" cx="-99" cy="-99"/><circle class="head" r="4" cx="-99" cy="-99"/>`;
      svg.innerHTML = html;
      head = svg.querySelector('.head'); headGlow = svg.querySelector('.head-glow');
      const groups = svg.querySelectorAll('g');
      routes = R.map((r, i) => {
        const els = [...groups[i].children], core = els[2], L = core.getTotalLength();
        const n = clamp(Math.round(L / 18), 40, 1200), sl = new Float32Array(n + 1), sy = new Float32Array(n + 1);
        for (let k = 0; k <= n; k++) { const l = L * k / n; sl[k] = l; sy[k] = core.getPointAtLength(l).y; }
        els.forEach(e => { e.style.strokeDasharray = `${L} ${L}`; e.style.strokeDashoffset = RM ? 0 : L; });
        return { ...r, els, core, L, sl, sy, cur: RM ? L : -1 };
      });
      if (!RM) draw();
    }

    function lengthAt(r, y) {
      const sy = r.sy, n = sy.length - 1;
      if (y <= sy[0]) return 0;
      for (let k = 1; k <= n; k++) {
        if (sy[k] > y) { const a = sy[k - 1], b = sy[k]; const f = b > a ? clamp((y - a) / (b - a), 0, 1) : 1; return r.sl[k - 1] + (r.sl[k] - r.sl[k - 1]) * f; }
      }
      return r.L;
    }

    function draw() {
      if (RM || !routes.length) return;
      const vh = innerHeight, max = Math.max(1, root.scrollHeight - vh), p = proxy.p, hf = num('--line-head', .62);
      const target = p * max - document.body.offsetTop + vh * (hf + (1 - hf) * Math.pow(p, 4));
      routes.forEach(r => {
        const len = lengthAt(r, target);
        if (Math.abs(len - r.cur) < .4) return;
        r.cur = len; const off = r.L - len;
        r.els.forEach(e => { e.style.strokeDashoffset = off; });
        if (r.main) {
          if (len > 1 && len < r.L - 1) {
            const pt = r.core.getPointAtLength(len);
            head.setAttribute('cx', pt.x); head.setAttribute('cy', pt.y);
            headGlow.setAttribute('cx', pt.x); headGlow.setAttribute('cy', pt.y);
          } else { head.setAttribute('cx', -99); headGlow.setAttribute('cx', -99); }
        }
      });
    }

    function init() {
      rebuild();
      if (RM) return;
      if (HAS_GSAP) {
        gsap.to(proxy, { p: 1, ease: 'none', onUpdate: draw, scrollTrigger: { start: 0, end: 'max', scrub: num('--line-scrub', .9) } });
        ScrollTrigger.addEventListener('refresh', rebuild);
      } else {
        const onS = () => { proxy.p = scrollY / Math.max(1, root.scrollHeight - innerHeight); draw(); };
        addEventListener('scroll', onS, { passive: true }); onS();
        let rt; addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(rebuild, 200); });
      }
    }
    return { init, rebuild };
  })();

  /* ---------- HOME HERO: the logo as a slow water ripple (canvas slice warp) ---------- */
  const Wordmark = (() => {
    const cv = $('#wordmark'); if (!cv) return { init() {} };
    const ctx = cv.getContext('2d');
    const src = document.createElement('canvas'), sctx = src.getContext('2d');
    const tmp = document.createElement('canvas'), tctx = tmp.getContext('2d');
    const logo = new Image(); logo.decoding = 'async';
    const RATIO = 395 / 1714;
    let w = 0, h = 0, size = 100, dpr = 1, visible = true, raf = 0, ready = false;
    let mx = -1e4, my = -1e4, inf = 0, infT = 0; const t0 = performance.now();
    const WS = num('--wave-speed', .3), WA = num('--wave-amp', .032), WF = num('--wave-follow', .035);

    function build() {
      dpr = DPR(); w = cv.parentElement.clientWidth;
      if (!w) return;
      const pad = Math.round(w * .02);
      size = w * RATIO; h = Math.round(size + pad * 2);
      [cv, src, tmp].forEach(c => { c.width = Math.round(w * dpr); c.height = Math.round(h * dpr); });
      cv.style.height = h + 'px';
      if (!ready) return;
      sctx.setTransform(1, 0, 0, 1, 0, 0); sctx.clearRect(0, 0, src.width, src.height);
      sctx.drawImage(logo, 0, Math.round(pad * dpr), Math.round(w * dpr), Math.round(size * dpr));
      if (RM) { ctx.clearRect(0, 0, cv.width, cv.height); ctx.drawImage(src, 0, 0); }
      else if (!raf && visible) raf = requestAnimationFrame(render);
    }

    function render(now) {
      raf = 0;
      if (!ready || !cv.width || !cv.height) return;
      const t = (now - t0) / 1000 * WS; inf += (infT - inf) * WF;
      const W = cv.width, Hh = cv.height, amp = size * WA * dpr;
      const myd = my * dpr, mxd = mx * dpr, sig = h * .32 * dpr, sigx = Math.max(90, w * .09) * dpr;
      const band = Math.max(2, Math.round(2 * dpr)), bandX = Math.max(2, Math.round(3 * dpr));
      const pull = clamp((mx / w) - .5, -.5, .5) * amp * 1.4;
      tctx.clearRect(0, 0, W, Hh);
      for (let y = 0; y < Hh; y += band) {
        const dy = y - myd, f = Math.exp(-(dy * dy) / (2 * sig * sig)) * inf;
        const o = Math.sin(y * .01 / dpr + t * 1.1) * 1.2 * dpr + f * (Math.sin(y * .028 / dpr - t * 4) * amp + pull);
        tctx.drawImage(src, 0, y, W, Math.min(band, Hh - y), o, y, W, Math.min(band, Hh - y));
      }
      ctx.clearRect(0, 0, W, Hh);
      for (let x = 0; x < W; x += bandX) {
        const dx = x - mxd, f = Math.exp(-(dx * dx) / (2 * sigx * sigx)) * inf;
        const o = Math.sin(x * .0035 / dpr + t * .9) * 1.1 * dpr + f * Math.sin(x * .018 / dpr - t * 3.2) * amp * .6;
        ctx.drawImage(tmp, x, 0, Math.min(bandX, W - x), Hh, x, o, Math.min(bandX, W - x), Hh);
      }
      if (visible) raf = requestAnimationFrame(render);
    }

    function init() {
      logo.onload = () => { ready = !!logo.naturalWidth; build(); };
      logo.src = cv.dataset.src || 'assets/pravaah-logo.svg';
      build();
      let lw = innerWidth;
      addEventListener('resize', () => { if (innerWidth !== lw) { lw = innerWidth; build(); } });
      if (RM) return;
      const hero = $('#hero');
      hero.addEventListener('pointermove', e => { const r = cv.getBoundingClientRect(); mx = e.clientX - r.left; my = e.clientY - r.top; infT = (my > -h * .5 && my < h * 1.5) ? 1 : .25; }, { passive: true });
      hero.addEventListener('pointerleave', () => { infT = 0; });
      new IntersectionObserver(([en]) => {
        visible = en.isIntersecting;
        if (visible && !raf) raf = requestAnimationFrame(render);
        if (!visible && raf) { cancelAnimationFrame(raf); raf = 0; }
      }).observe(cv);
    }
    return { init };
  })();

  /* ---------- HOME HERO: rotating words, each with its own motion ---------- */
  function initRotator() {
    const words = $$('.rot-word'); if (!words.length) return;
    words.forEach(w => { const t = w.textContent; w.textContent = ''; [...t].forEach(ch => { const s = document.createElement('span'); s.className = 'ch'; s.textContent = ch; w.appendChild(s); }); });
    const hold = num('--rotate-hold', 1.8);
    if (!HAS_GSAP) {
      let i = 0; words.forEach((w, k) => { w.style.visibility = 'visible'; w.style.opacity = k ? 0 : 1; w.style.transition = 'opacity .6s'; });
      setInterval(() => { words[i].style.opacity = 0; i = (i + 1) % words.length; words[i].style.opacity = 1; }, (hold + 1) * 1000);
      return;
    }
    gsap.set(words, { autoAlpha: 0 });
    const tl = gsap.timeline({ repeat: -1 });
    const ch = w => w.querySelectorAll('.ch');
    if (RM) {
      words.forEach(w => tl.to(w, { autoAlpha: 1, duration: .6 }).to(w, { autoAlpha: 0, duration: .6 }, `+=${hold}`));
    } else {
      const motions = [
        // Discover: letters surface one by one
        w => tl.set(w, { autoAlpha: 1 })
          .fromTo(ch(w), { yPercent: 110, opacity: 0 }, { yPercent: 0, opacity: 1, duration: .8, ease: 'expo.out', stagger: .05 })
          .to(ch(w), { yPercent: -110, opacity: 0, duration: .45, ease: 'power3.in', stagger: .03 }, `+=${hold}`).set(w, { autoAlpha: 0 }),
        // Imagine: a lens pulling focus
        w => tl.set(w, { autoAlpha: 1 })
          .fromTo(w, { scale: 1.3, filter: 'blur(14px)', opacity: 0, letterSpacing: '.22em' }, { scale: 1, filter: 'blur(0px)', opacity: 1, letterSpacing: '0em', duration: 1, ease: 'expo.out' })
          .to(w, { scale: .86, filter: 'blur(10px)', opacity: 0, duration: .45, ease: 'power2.in' }, `+=${hold}`).set(w, { autoAlpha: 0 }),
        // Create: letters set into place with a little bounce
        w => tl.set(w, { autoAlpha: 1 })
          .fromTo(ch(w), { y: i => -40 - i * 6, scale: .4, opacity: 0 }, { y: 0, scale: 1, opacity: 1, duration: 1, ease: 'elastic.out(1,.5)', stagger: .06 })
          .to(ch(w), { y: 30, opacity: 0, duration: .4, ease: 'power2.in', stagger: .03 }, `+=${hold}`).set(w, { autoAlpha: 0 }),
        // Evolve: letters turn over into their next form
        w => tl.set(w, { autoAlpha: 1 })
          .fromTo(ch(w), { rotationX: -90, opacity: 0, transformOrigin: '50% 50% -20px' }, { rotationX: 0, opacity: 1, duration: .9, ease: 'power3.out', stagger: .07 })
          .to(ch(w), { rotationX: 90, opacity: 0, duration: .45, ease: 'power2.in', stagger: .04 }, `+=${hold}`).set(w, { autoAlpha: 0 })
      ];
      words.forEach((w, i) => motions[i % motions.length](w));
    }
    ScrollTrigger.create({ trigger: '#hero', start: 'top top', end: 'bottom top', onLeave: () => tl.pause(), onEnterBack: () => tl.play() });
  }

  /* marquee pauses off-screen */
  (() => { const m = $('.marquee'); if (!m || !('IntersectionObserver' in window)) return; new IntersectionObserver(([e]) => m.classList.toggle('is-paused', !e.isIntersecting)).observe(m); })();

  /* ---------- HOME ABOUT: the current behind the copy, calm to wild ---------- */
  const About = (() => {
    const cv = $('#aboutCanvas'); if (!cv) return { init() {} };
    const ctx = cv.getContext('2d'), sec = $('#about'), meter = $('.meter span');
    let W = 0, H = 0, dpr = 1, grad, visible = false, raf = 0, last = 0, t = 0;
    let chaos = 0, scrollChaos = 0, hover = null;
    const cs = num('--calm-speed', .22), ws = num('--wild-speed', 2.6), ca = num('--calm-amp', 10), wa = num('--wild-amp', 74);
    function size() {
      dpr = DPR(); W = cv.clientWidth; H = cv.clientHeight; if (!W || !H) return;
      cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      grad = ctx.createLinearGradient(0, 0, W, 0);
      grad.addColorStop(0, COL.l3); grad.addColorStop(.5, COL.l1); grad.addColorStop(1, COL.violet);
    }
    function paint() {
      if (!W || !H) return;
      ctx.clearRect(0, 0, W, H);
      const n = W < 760 ? 14 : 24, step = W < 760 ? 18 : 14, amp = lerp(ca, wa, chaos);
      ctx.strokeStyle = grad; ctx.lineWidth = 1.2;
      for (let i = 0; i < n; i++) {
        const base = H * (.1 + .8 * i / (n - 1)), a = amp * (.6 + .4 * Math.sin(i * 1.7));
        ctx.globalAlpha = (i % 3 === 0 ? .42 : .2) + chaos * .14;
        ctx.beginPath();
        for (let x = -20; x <= W + 20; x += step) {
          const y = base + Math.sin(x * .004 + t * .9 + i * .5) * a
            + Math.sin(x * .011 - t * 1.7 + i) * a * .35 * (.3 + chaos)
            + chaos * Math.sin(x * .031 + t * 3.1 + i * 2.3) * a * .28;
          x < -10 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }
    const setMeter = () => { if (meter) meter.style.transform = `scaleX(${(.08 + chaos * .92).toFixed(3)})`; };
    function frame(now) {
      raf = 0; const dt = clamp((now - last) / 1000 || .016, 0, .05); last = now;
      const target = hover ?? scrollChaos;
      chaos += (target - chaos) * Math.min(1, dt * 2.4);
      t += dt * lerp(cs, ws, chaos);
      paint(); setMeter();
      if (visible) raf = requestAnimationFrame(frame);
    }
    function setHover(v, btn) {
      hover = v;
      $$('.mood').forEach(b => b.setAttribute('aria-pressed', String(v !== null && b === btn)));
      if (RM) { chaos = v ?? 0; paint(); setMeter(); }
    }
    function init() {
      size(); paint();
      addEventListener('resize', () => { size(); paint(); });
      $$('.mood').forEach(b => {
        const v = clamp(parseFloat(b.dataset.chaos) || 0, 0, 1);
        if (FINE) { b.addEventListener('pointerenter', () => setHover(v, b)); b.addEventListener('pointerleave', () => setHover(null)); }
        b.addEventListener('focus', () => setHover(v, b));
        b.addEventListener('blur', () => setHover(null));
        b.addEventListener('click', () => setHover(hover === v && b.getAttribute('aria-pressed') === 'true' ? null : v, b));
      });
      if (RM) return;
      new IntersectionObserver(([e]) => {
        visible = e.isIntersecting;
        if (visible && !raf) { last = performance.now(); raf = requestAnimationFrame(frame); }
        if (!visible && raf) { cancelAnimationFrame(raf); raf = 0; }
      }, { rootMargin: '100px' }).observe(sec);
      if (HAS_GSAP) ScrollTrigger.create({
        trigger: sec, start: 'top 70%', end: 'bottom 30%',
        onUpdate: s => { const p = s.progress; scrollChaos = p < .1 ? 0 : p < .4 ? (p - .1) / .3 : p < .8 ? 1 - (p - .4) / .4 * .6 : .4; }
      });
    }
    return { init };
  })();

  /* ---------- scroll reveals, word-by-word text, parallax, journey, tenets ---------- */
  function splitWords(node) {
    [...node.childNodes].forEach(n => {
      if (n.nodeType === 3) {
        const frag = document.createDocumentFragment();
        n.textContent.split(/(\s+)/).forEach(p => {
          if (!p) return;
          if (/^\s+$/.test(p)) frag.appendChild(document.createTextNode(p));
          else { const s = document.createElement('span'); s.className = 'w'; s.textContent = p; frag.appendChild(s); }
        });
        n.replaceWith(frag);
      } else if (n.nodeType === 1) splitWords(n);
    });
  }
  function initReveals() {
    const steps = $$('.step');
    if (!HAS_GSAP || RM) steps.forEach(s => s.classList.add('is-lit'));
    if (!HAS_GSAP) return;
    const dur = num('--reveal-duration', 1.3), narrow = innerWidth < 760;
    $$('[data-reveal]').forEach((el, i) => {
      const dir = el.dataset.reveal;
      const from = RM ? { opacity: .15 } : { opacity: .15, y: 60, x: narrow ? 0 : dir === 'left' ? -50 : dir === 'right' ? 50 : 0 };
      gsap.from(el, { ...from, duration: RM ? .6 : dur, ease: EASE, delay: el.matches('.member, .principle') ? (i % 3) * .08 : 0, scrollTrigger: { trigger: el, start: 'top 90%', once: true } });
    });
    $$('[data-words]').forEach(copy => {
      splitWords(copy);
      if (RM) { gsap.from(copy, { opacity: .15, duration: .8, scrollTrigger: { trigger: copy, start: 'top 80%', once: true } }); return; }
      gsap.fromTo($$('.w', copy), { opacity: .14 }, { opacity: 1, ease: 'none', stagger: .1, scrollTrigger: { trigger: copy, start: 'top 78%', end: 'bottom 55%', scrub: true } });
    });
    if (RM) return;
    // journey: each node lights when the current reaches it
    const headPct = Math.round(num('--line-head', .62) * 100);
    steps.forEach(s => ScrollTrigger.create({ trigger: $('.node', s), start: `center ${headPct}%`, onEnter: () => s.classList.add('is-lit'), onLeaveBack: () => s.classList.remove('is-lit') }));
    // tenets: the second half flows in to complete the first
    $$('.tenet').forEach(t => {
      const b = $('.t-b', t);
      gsap.fromTo(b, { x: () => innerWidth * (narrow ? .06 : .1), opacity: .12 }, { x: 0, opacity: 1, ease: 'none', scrollTrigger: { trigger: t, start: 'top 88%', end: 'top 48%', scrub: true, invalidateOnRefresh: true } });
    });
    $$('[data-parallax]').forEach(el => {
      const v = parseFloat(el.dataset.parallax) || 8;
      gsap.fromTo(el, { yPercent: v }, { yPercent: -v, ease: 'none', scrollTrigger: { trigger: el, start: 'top bottom', end: 'bottom top', scrub: true } });
    });
    if ($('.ghost')) gsap.to('.ghost', { xPercent: -18, ease: 'none', scrollTrigger: { trigger: '#about', start: 'top bottom', end: 'bottom top', scrub: true } });
  }

  /* ---------- pebbles: magnetic pull + ripple ---------- */
  function initPebbles() {
    const ripple = (host, e) => {
      if (RM) return;
      const r = host.getBoundingClientRect(), s = document.createElement('span');
      s.className = 'pebble-ripple'; s.style.left = (e.clientX - r.left) + 'px'; s.style.top = (e.clientY - r.top) + 'px';
      host.appendChild(s); s.addEventListener('animationend', () => s.remove());
    };
    const magnet = (hit, move, k) => {
      if (!FINE || RM || !HAS_GSAP) return;
      const qx = gsap.quickTo(move, 'x', { duration: .7, ease: 'power3' }), qy = gsap.quickTo(move, 'y', { duration: .7, ease: 'power3' });
      hit.addEventListener('pointermove', e => { const r = hit.getBoundingClientRect(); qx((e.clientX - r.left - r.width / 2) * k); qy((e.clientY - r.top - r.height / 2) * k); });
      hit.addEventListener('pointerleave', () => { qx(0); qy(0); });
    };
    $$('.cluster .pebble').forEach(p => { p.addEventListener('pointerenter', e => ripple(p, e)); magnet(p, p, .25); });
    $$('.member').forEach(m => {
      const front = $('.front', m);
      m.addEventListener('pointerenter', e => ripple(front, e));
      magnet(m, $('.mag', m), .1);
    });
  }

  /* ---------- cursor + ink-in-water trail (desktop) / tap ripple (touch) ---------- */
  const Cursor = { on() {}, off() {} };
  function initCursor() {
    if (!RM) addEventListener('pointerdown', e => {
      if (e.pointerType === 'mouse') return;
      const r = document.createElement('span'); r.className = 'tap-ripple';
      r.style.left = e.clientX + 'px'; r.style.top = e.clientY + 'px';
      document.body.appendChild(r); r.addEventListener('animationend', () => r.remove());
    }, { passive: true });
    if (!FINE || RM) return;
    const cur = $('.cursor'), cv = $('#ink'); if (!cur || !cv) return;
    const ctx = cv.getContext('2d');
    let enabled = true;
    root.classList.add('has-cursor');
    Cursor.off = () => { enabled = false; root.classList.remove('has-cursor'); cur.classList.remove('is-on'); };
    Cursor.on = () => { enabled = true; root.classList.add('has-cursor'); };
    let W = 1, H = 1;
    const resize = () => { const d = DPR(); W = innerWidth; H = innerHeight; cv.width = W * d; cv.height = H * d; ctx.setTransform(d, 0, 0, d, 0, 0); };
    resize(); addEventListener('resize', resize);
    // dye colours: magenta into the logo's coral and amber
    const stops = [COL.magenta, COL.l3, COL.l1].map(hex2rgb), steps = 12, sprites = [];
    for (let i = 0; i < steps; i++) {
      const k = i / (steps - 1) * (stops.length - 1), a = Math.floor(Math.min(k, stops.length - 2)), f = k - a;
      const c = stops[a].map((v, j) => Math.round(lerp(v, stops[a + 1][j], f)));
      const s = document.createElement('canvas'); s.width = s.height = 64; const x = s.getContext('2d');
      const gr = x.createRadialGradient(32, 32, 0, 32, 32, 32);
      gr.addColorStop(0, `rgba(${c},.9)`); gr.addColorStop(.4, `rgba(${c},.35)`); gr.addColorStop(1, `rgba(${c},0)`);
      x.fillStyle = gr; x.fillRect(0, 0, 64, 64); sprites.push(s);
    }
    const P = [], MAX = num('--trail-max', 240), LIFE = num('--trail-life', 1.6);
    let mx = -100, my = -100, px = mx, py = my, cx = mx, cy = my, running = false, last = 0, seeded = false;
    addEventListener('pointermove', e => {
      if (e.pointerType !== 'mouse' || !enabled) return;
      mx = e.clientX; my = e.clientY;
      if (!seeded) { px = cx = mx; py = cy = my; seeded = true; }
      cur.classList.add('is-on'); kick();
    }, { passive: true });
    document.addEventListener('mouseleave', () => cur.classList.remove('is-on'));
    document.addEventListener('pointerover', e => {
      const t = e.target.closest('[data-cursor], a, button, input, textarea, label');
      cur.dataset.state = t ? (t.dataset.cursor || 'link') : '';
    });
    function emit() {
      const dx = mx - px, dy = my - py, dist = Math.hypot(dx, dy);
      const n = Math.min(6, Math.ceil(dist / 8));
      for (let i = 0; i < n; i++) {
        if (P.length >= MAX) P.shift();
        const k = (i + 1) / n;
        P.push({ x: px + dx * k, y: py + dy * k, vx: dx * .035 + (Math.random() - .5) * .5, vy: dy * .035 + (Math.random() - .5) * .5, r: 5 + Math.random() * 6, a: 0, life: LIFE * (.7 + Math.random() * .6), s: Math.random() * 100 });
      }
      px = mx; py = my;
    }
    function frame(now) {
      const dt = clamp((now - last) / 1000 || .016, 0, .05); last = now;
      emit();
      ctx.clearRect(0, 0, W, H); ctx.globalCompositeOperation = 'lighter';
      const tt = now * .001;
      for (let i = P.length - 1; i >= 0; i--) {
        const p = P[i]; p.a += dt; const k = clamp(p.a / p.life, 0, 1);
        if (k >= 1) { P.splice(i, 1); continue; }
        const ang = (Math.sin(p.x * .011 + tt * 1.1 + p.s) + Math.cos(p.y * .013 - tt * .9)) * Math.PI;
        p.vx = (p.vx + Math.cos(ang) * .07) * .962; p.vy = (p.vy + Math.sin(ang) * .07 - .008) * .962;
        p.x += p.vx; p.y += p.vy;
        const rad = p.r * (1 + k * 3.4);
        const sprite = sprites[clamp(Math.floor(k * steps), 0, steps - 1)];
        if (!sprite) continue;
        ctx.globalAlpha = (1 - k) * (1 - k) * .34 * Math.min(1, p.a * 10);
        ctx.drawImage(sprite, p.x - rad, p.y - rad, rad * 2, rad * 2);
      }
      ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
      cx += (mx - cx) * .25; cy += (my - cy) * .25;
      cur.style.transform = `translate3d(${cx.toFixed(1)}px,${cy.toFixed(1)}px,0)`;
      if (P.length || Math.abs(mx - cx) > .3 || Math.abs(my - cy) > .3) requestAnimationFrame(frame);
      else { running = false; ctx.clearRect(0, 0, W, H); }
    }
    function kick() { if (!running) { running = true; last = performance.now(); requestAnimationFrame(frame); } }
  }

  /* ---------- "Start a Conversation" form ---------- */
  function initTalk() {
    const dlg = $('#talk'); if (!dlg) return;
    const form = $('form', dlg), done = $('.talk-done', dlg), status = $('.form-status', dlg), submit = $('button[type="submit"]', form);
    const doneName = $('[data-done-name]', dlg), doneEmail = $('[data-done-email]', dlg);
    const TO = form.dataset.to || 'team@pravaah.work';
    const open = reason => {
      if (reason) { const r = $(`input[name="reason"][value="${reason}"]`, form); if (r) r.checked = true; }
      form.hidden = false; done.hidden = true; status.textContent = '';
      if (typeof dlg.showModal === 'function') dlg.showModal(); else dlg.setAttribute('open', '');
      if (lenis) lenis.stop(); Cursor.off();
      setTimeout(() => { const f = $('#f-name', form); if (f) f.focus(); }, 60);
    };
    const close = () => { if (typeof dlg.close === 'function') dlg.close(); else { dlg.removeAttribute('open'); onClose(); } };
    const onClose = () => { if (lenis) lenis.start(); Cursor.on(); };
    dlg.addEventListener('close', onClose);
    $$('[data-open-form]').forEach(b => b.addEventListener('click', e => { e.preventDefault(); open(b.dataset.reason); }));
    $$('[data-close-form]', dlg).forEach(b => b.addEventListener('click', close));
    dlg.addEventListener('click', e => { if (e.target === dlg) close(); });   // click on the dimmed backdrop

    const failMsg = () => {
      status.innerHTML = '';
      status.append('We couldn’t send your message just now. Please email us at ');
      const a = document.createElement('a'); a.href = `mailto:${TO}`; a.textContent = TO; status.append(a, ' instead.');
    };
    form.addEventListener('submit', async e => {
      e.preventDefault();
      status.textContent = '';
      if (!form.reportValidity()) return;
      const fd = new FormData(form);
      if (fd.get('_honey')) return;                         // a bot filled the hidden field
      const data = Object.fromEntries(fd.entries());
      const reasonLabel = { project: 'A project or idea', team: 'Joining the team', other: 'Something else' }[data.reason] || data.reason || 'General';
      const payload = {
        name: data.name, email: data.email, phone: data.phone || '(not given)', reason: reasonLabel, message: data.message,
        _subject: `Pravaah website: ${reasonLabel} from ${data.name}`, _replyto: data.email, _template: 'table', _captcha: 'false'
      };
      submit.disabled = true; const label = submit.innerHTML; submit.textContent = 'Sending…';
      try {
        const res = await fetch(form.action, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(payload) });
        const out = await res.json().catch(() => ({}));
        const ok = res.ok && (String(out.success) === 'true' || /activat/i.test(out.message || ''));
        if (!ok) throw new Error(out.message || res.status);
        if (doneName) doneName.textContent = data.name.split(' ')[0];
        if (doneEmail) doneEmail.textContent = data.email;
        form.reset(); form.hidden = true; done.hidden = false;
        const f = $('[data-close-form]', done); if (f) f.focus();
      } catch (err) {
        failMsg();
      } finally {
        submit.disabled = false; submit.innerHTML = label;
      }
    });
  }

  /* ---------- copy email ---------- */
  $$('.copy').forEach(b => b.addEventListener('click', () => {
    const v = b.dataset.copy, status = b.parentElement.querySelector('.copy-status');
    const done = msg => { if (status) { status.textContent = msg; setTimeout(() => status.textContent = '', 2400); } };
    const fallback = () => { const t = b.parentElement.querySelector('.mail-text'); const r = document.createRange(); r.selectNodeContents(t); const s = getSelection(); s.removeAllRanges(); s.addRange(r); done('Selected, press Ctrl+C'); };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(v).then(() => done('Copied'), fallback); else fallback();
  }));

  /* ---------- boot ---------- */
  renderTeam();
  initFlip();
  Wordmark.init();
  initRotator();
  About.init();
  initReveals();
  initPebbles();
  initCursor();
  initTalk();
  Current.init();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(scheduleRefresh);
  addEventListener('load', scheduleRefresh);
})();
