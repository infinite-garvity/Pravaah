Put team photos here, e.g. asha.jpg (square, 600x600 or larger).
